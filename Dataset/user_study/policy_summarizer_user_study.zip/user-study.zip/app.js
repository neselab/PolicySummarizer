// User Study Application

// ============================================
// JSONBIN CONFIGURATION - ADD YOUR API KEY HERE
// ============================================
const JSONBIN_CONFIG = {
  apiKey: '',  // Replace with your X-Master-Key from jsonbin.io
  collectionId: null,           // Optional: set after creating a collection
  binName: 'PolicySummarizer User Study'
};

// Submit responses to JSONBin
async function submitToJSONBin(data) {
  if (JSONBIN_CONFIG.apiKey === 'YOUR_API_KEY_HERE') {
    console.warn('JSONBin API key not configured. Data saved locally only.');
    return { success: false, error: 'API key not configured' };
  }

  try {
    const response = await fetch('https://api.jsonbin.io/v3/b', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Master-Key': JSONBIN_CONFIG.apiKey,
        'X-Bin-Name': `${JSONBIN_CONFIG.binName} - ${data.participantId}`,
        ...(JSONBIN_CONFIG.collectionId && { 'X-Collection-Id': JSONBIN_CONFIG.collectionId })
      },
      body: JSON.stringify(data)
    });

    const result = await response.json();

    if (response.ok) {
      console.log('✅ Data submitted to JSONBin:', result.metadata.id);
      return { success: true, binId: result.metadata.id };
    } else {
      console.error('JSONBin error:', result);
      return { success: false, error: result.message };
    }
  } catch (error) {
    console.error('Failed to submit to JSONBin:', error);
    return { success: false, error: error.message };
  }
}

class UserStudy {
  constructor() {
    this.participantId = null;
    this.group = null;
    this.currentStep = 0;
    this.taskOrder = [];
    this.responses = {
      demographics: {},
      tasks: [],
      postStudy: {}
    };
    this.currentTaskStartTime = null;
    this.timerInterval = null;

    this.steps = [
      'consent',
      'demographics',
      'tutorial',
      'instructions',
      'task-1-first',
      'task-2-first',
      'task-1-second',
      'task-2-second',
      'post-study',
      'complete'
    ];

    this.init();
  }

  init() {
    // Generate participant ID
    this.participantId = 'P_' + Date.now();

    // Assign to counterbalancing group (alternates based on timestamp)
    this.group = Date.now() % 2;

    // Load any saved progress
    this.loadProgress();

    // Setup tutorial modal
    this.setupTutorialModal();

    // Render current step
    this.render();
  }

  setupTutorialModal() {
    const overlay = document.getElementById('tutorialModal');
    const closeBtn = document.getElementById('tutorialModalClose');
    const content = document.getElementById('tutorialModalContent');

    // Close on X button
    closeBtn.addEventListener('click', () => this.closeTutorial());

    // Close on overlay click (outside modal)
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) this.closeTutorial();
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.closeTutorial();
    });

    // Populate with condensed reference content
    content.innerHTML = this.getTutorialReferenceContent();
  }

  openTutorial() {
    document.getElementById('tutorialModal').classList.add('active');
  }

  closeTutorial() {
    document.getElementById('tutorialModal').classList.remove('active');
  }

  getTutorialReferenceContent() {
    return `
      <h2 style="margin-bottom: 1rem; background: linear-gradient(135deg, var(--accent), var(--accent-hover)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">📚 Quick Reference</h2>

      <h3>📄 Reading Policy JSON</h3>
      <table style="width: 100%; border-collapse: collapse; margin: 0.5rem 0 1rem; font-size: 0.85rem;">
        <tr style="background: var(--bg-tertiary);">
          <th style="padding: 0.4rem; text-align: left; border-bottom: 1px solid var(--border);">Policy Field</th>
          <th style="padding: 0.4rem; text-align: left; border-bottom: 1px solid var(--border);">Meaning</th>
        </tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Effect: "Allow"</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">✅ Grants access</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Effect: "Deny"</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">🚫 Blocks access (overrides Allow!)</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Action: "s3:GetObject"</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">📥 Read/download files</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Action: "s3:PutObject"</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">📤 Write/upload files</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Action: "s3:DeleteObject"</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">🗑️ Delete files</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Action: "s3:Get*"</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">⚠️ ALL Get actions (14+ actions, not just GetObject!)</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Action: "s3:*"</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">⚠️ ALL S3 actions (read, write, delete, everything)</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Resource</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">📁 Folders/files this rule applies TO</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>NotResource</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">📁 Everything EXCEPT these folders</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>Condition</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">🔒 Extra requirements (MFA, encryption, etc.)</td></tr>
        <tr><td style="padding: 0.4rem;"><code>Resource: "*"</code></td><td style="padding: 0.4rem;">⚠️ Applies to ALL resources everywhere</td></tr>
      </table>

      <hr style="margin: 1rem 0; border-color: var(--border);">

      <h3>📊 Reading Resource Regexes (PolicySummarizer)</h3>
      <table style="width: 100%; border-collapse: collapse; margin: 0.5rem 0 1rem; font-size: 0.85rem;">
        <tr style="background: var(--bg-tertiary);">
          <th style="padding: 0.4rem; text-align: left; border-bottom: 1px solid var(--border);">Regex Pattern</th>
          <th style="padding: 0.4rem; text-align: left; border-bottom: 1px solid var(--border);">Meaning</th>
        </tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>bucket/logs/.*</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">Only the logs/ folder</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>bucket/(?!admin/).*</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">Everything EXCEPT admin/</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>bucket/(docs|assets)/.*</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">Only docs/ and assets/</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>bucket/(?!x/|y/|z/).*</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">Everything EXCEPT x/, y/, and z/</td></tr>
        <tr><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);"><code>bucket/team-[a-z]+/.*</code></td><td style="padding: 0.4rem; border-bottom: 1px solid var(--border);">Any team folder (team-alpha, team-beta, etc.)</td></tr>
        <tr><td style="padding: 0.4rem;"><code>.*</code></td><td style="padding: 0.4rem;">⚠️ Everything — the policy is wide open!</td></tr>
      </table>

      <h3>📋 Differential Output</h3>
      <div style="background: var(--bg-tertiary); padding: 0.75rem; border-radius: 8px; margin: 0.5rem 0; font-size: 0.85rem;">
        <p style="margin: 0.3rem 0;">📋 <strong>Added:</strong> Resource paths now accessible that weren't before</p>
        <p style="margin: 0.3rem 0;">📋 <strong>Removed:</strong> Resource paths no longer accessible</p>
        <p style="margin: 0.3rem 0;">📋 <strong>∅</strong> = empty set (nothing in this category)</p>
      </div>
    `;
  }

  loadProgress() {
    const saved = localStorage.getItem('userStudyProgress');
    if (saved) {
      const data = JSON.parse(saved);
      this.participantId = data.participantId;
      this.group = data.group;
      this.currentStep = data.currentStep;
      this.responses = data.responses;
    }
  }

  saveProgress() {
    localStorage.setItem('userStudyProgress', JSON.stringify({
      participantId: this.participantId,
      group: this.group,
      currentStep: this.currentStep,
      responses: this.responses,
      savedAt: new Date().toISOString()
    }));
  }

  updateProgress() {
    const progress = ((this.currentStep + 1) / this.steps.length) * 100;
    document.getElementById('progressFill').style.width = `${progress}%`;
    document.getElementById('progressText').textContent = `Step ${this.currentStep + 1} of ${this.steps.length}`;
  }

  render() {
    this.updateProgress();
    const step = this.steps[this.currentStep];

    switch (step) {
      case 'consent':
        this.renderConsent();
        break;
      case 'demographics':
        this.renderDemographics();
        break;
      case 'tutorial':
        this.renderTutorial();
        break;
      case 'instructions':
        this.renderInstructions();
        break;
      case 'task-1-first':
      case 'task-2-first':
      case 'task-1-second':
      case 'task-2-second':
        this.renderTask(step);
        break;
      case 'post-study':
        this.renderPostStudy();
        break;
      case 'complete':
        this.renderComplete();
        break;
    }
  }

  renderConsent() {
    const main = document.getElementById('mainContent');
    main.innerHTML = `
      <div class="card">
        <h1>PolicySummarizer User Study</h1>
        <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">Informed Consent for Research Participation</p>
        <p>Thank you for your interest in this research study. Please read the following information carefully before deciding whether to participate.</p>
        
        <div class="consent-section">
          <h2>1. Purpose of the Study</h2>
          <p>This research investigates the effectiveness of <strong>PolicySummarizer</strong>, an automated tool for analyzing access control policies. The goal is to measure whether formal summarization (resource regex characterization) improves the <strong>accuracy</strong>, <strong>efficiency</strong>, and <strong>confidence</strong> of engineers when reviewing cloud security (IAM) policies, compared to manual review of raw policy JSON alone.</p>
          <p>Your responses will be used to evaluate the tool's impact. Data will be reported only in aggregate or anonymized form.</p>
        </div>

        <div class="consent-section">
          <h2>2. Procedures</h2>
          <p>If you agree to participate, you will:</p>
          <ul style="margin-left: 1.5rem; margin-bottom: 0.5rem; color: var(--text-secondary);">
            <li>Provide brief background information about your experience with cloud platforms and access control (demographic survey)</li>
            <li>Complete a guided tutorial explaining how to read policies and PolicySummarizer output</li>
            <li>Complete <strong>4 policy review tasks</strong> across 2 scenarios — each scenario is presented twice: once with only the raw JSON policy (baseline) and once with the additional PolicySummarizer analysis (treatment)</li>
            <li>Rate your confidence after each task and complete a brief post-study workload assessment (NASA-TLX)</li>
          </ul>
          <p>The study takes approximately <strong>10–15 minutes</strong> to complete in a single session via this web-based platform.</p>
        </div>

        <div class="consent-section">
          <h2>3. Voluntary Participation</h2>
          <p>Your participation is entirely <strong>voluntary</strong>. You may choose not to participate, and you may <strong>withdraw at any time</strong> during the study without penalty or loss of any benefits to which you are otherwise entitled. If you withdraw, any data collected up to that point will be discarded and not used in the analysis. Simply close this browser tab to discontinue participation.</p>
        </div>

        <div class="consent-section">
          <h2>4. Risks</h2>
          <p>The risks associated with this study are <strong>minimal</strong> and are no greater than those encountered in everyday computer use. You will be asked to review security policy documents and answer questions about them. There is no deception involved. Some participants may experience minor fatigue or frustration from the policy review tasks.</p>
        </div>

        <div class="consent-section">
          <h2>5. Data Privacy &amp; Confidentiality</h2>
          <p>We take your privacy seriously:</p>
          <ul style="margin-left: 1.5rem; margin-bottom: 0.5rem; color: var(--text-secondary);">
            <li><strong>No personally identifiable information (PII)</strong> is collected — no name, email, IP address, or account is recorded</li>
            <li>You are assigned a randomized participant ID (e.g., <code>P_1234567890</code>) that cannot be traced back to you</li>
            <li>Collected data includes: task answers, time-on-task, self-reported confidence ratings, and optional demographic responses</li>
            <li>Data is transmitted securely (HTTPS) and stored in an access-restricted repository</li>
            <li>All results will be reported in <strong>aggregate or anonymized</strong> form only — no individual responses will be identifiable in any publication or presentation</li>
            <li>Data will be retained for the duration of the research project and securely deleted afterwards</li>
          </ul>
        </div>

        <div class="consent-section">
          <h2>6. Compensation</h2>
          <p>There is <strong>no monetary compensation</strong> for participating in this study. Your participation is voluntary and contributes to advancing research in automated security policy analysis.</p>
        </div>

        <div class="consent-section">
          <h2>7. Contact Information</h2>
          <p>If you have questions, concerns, or wish to report an issue related to this study, please contact the Principal Investigator:</p>
          <div style="background: var(--bg-tertiary); padding: 1rem; border-radius: 8px; margin-top: 0.5rem;">
            <p style="margin: 0.25rem 0;"><strong>Principal Investigator:</strong> William Eiers</p>
            <p style="margin: 0.25rem 0;"><strong>Email:</strong> <a href="mailto:weiers@stevens.edu" style="color: var(--accent);">weiers@stevens.edu</a></p>
            <p style="margin: 0.25rem 0;"><strong>Institution:</strong> Stevens Institute of Technology</p>
          </div>
        </div>

        <hr style="margin: 2rem 0; border-color: var(--border);">

        <div class="consent-box">
          <input type="checkbox" id="consentCheck">
          <label for="consentCheck">I have read and understand the information provided above regarding the purpose, procedures, risks, data handling, compensation, and contact information for this study. I voluntarily agree to participate. I understand that I may withdraw at any time without penalty.</label>
        </div>
        
        <div class="button-group">
          <button class="btn btn-primary" id="consentBtn" disabled>Begin Study</button>
        </div>
      </div>
    `;

    const checkbox = document.getElementById('consentCheck');
    const btn = document.getElementById('consentBtn');

    checkbox.addEventListener('change', () => {
      btn.disabled = !checkbox.checked;
    });

    btn.addEventListener('click', () => {
      this.responses.consentTime = new Date().toISOString();
      this.nextStep();
    });
  }

  renderDemographics() {
    const main = document.getElementById('mainContent');
    main.innerHTML = `
      <div class="card">
        <h1>Background Information</h1>
        <p>Please tell us about your experience. This helps us analyze results across different experience levels.</p>
        
        <form id="demographicsForm">

          
          <div class="form-group">
            <label>How familiar are you with AWS (or similar cloud platforms)?</label>
            <div class="likert-scale">
              ${[1, 2, 3, 4, 5].map(n => `
                <div class="likert-option">
                  <input type="radio" name="awsExperience" id="aws${n}" value="${n}" required>
                  <label for="aws${n}">${n}</label>
                </div>
              `).join('')}
            </div>
            <div class="likert-labels">
              <span>No experience</span>
              <span>Expert</span>
            </div>
          </div>
          
          <div class="form-group">
            <label>How familiar are you with IAM/access control policies?</label>
            <div class="likert-scale">
              ${[1, 2, 3, 4, 5].map(n => `
                <div class="likert-option">
                  <input type="radio" name="iamExperience" id="iam${n}" value="${n}" required>
                  <label for="iam${n}">${n}</label>
                </div>
              `).join('')}
            </div>
            <div class="likert-labels">
              <span>Never seen one</span>
              <span>Write them regularly</span>
            </div>
          </div>
          
          <div class="form-group">
            <label for="codeReview">How often do you review code or policies?</label>
            <select id="codeReview" required>
              <option value="">Select...</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="rarely">Rarely</option>
              <option value="never">Never</option>
            </select>
          </div>
          
          <div class="button-group">
            <button type="button" class="btn btn-secondary" id="backBtn">← Back</button>
            <button type="submit" class="btn btn-primary">Continue</button>
          </div>
        </form>
      </div>
    `;

    document.getElementById('backBtn').addEventListener('click', () => this.prevStep());

    document.getElementById('demographicsForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.responses.demographics = {
        awsExperience: parseInt(document.querySelector('input[name="awsExperience"]:checked').value),
        iamExperience: parseInt(document.querySelector('input[name="iamExperience"]:checked').value),
        codeReviewFrequency: document.getElementById('codeReview').value
      };
      this.nextStep();
    });
  }

  renderTutorial() {
    const main = document.getElementById('mainContent');
    main.innerHTML = `
      <div class="card">
        <h1>📚 Tutorial: Everything You Need to Know</h1>
        <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">Don't worry if you've never seen a policy before — we'll walk you through everything step by step!</p>
        
        <h2>🔐 What is an Access Control Policy?</h2>
        <p>Imagine a <strong>digital security guard</strong> at a file storage system (like Amazon S3). The policy is the guard's rulebook that controls <strong>which folders and files</strong> someone can access.</p>
        
        <div style="background: var(--bg-tertiary); padding: 1rem; border-radius: 8px; margin: 1rem 0;">
          <p style="margin: 0.5rem 0;">1️⃣ <strong>ALLOW or DENY?</strong> — Is access permitted or blocked?</p>
          <p style="margin: 0.5rem 0;">2️⃣ <strong>WHAT action?</strong> — Reading files? Writing files? Deleting files?</p>
          <p style="margin: 0.5rem 0;">3️⃣ <strong>WHICH folders?</strong> — Which specific resource paths can they access?</p>
        </div>
        
        <hr style="margin: 1.5rem 0; border-color: var(--border);">
        
        <h2>📖 Reading a Policy: Line by Line</h2>
        <p>Here's a simple policy with each part explained:</p>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin: 1rem 0;">
          <pre style="font-size: 0.75rem; overflow-x: auto; margin: 0;">{
  "Statement": [{
    
    "Effect": "Allow",
    
    "Action": "s3:GetObject",
    
    "Resource": "...bucket/public/*"
  }]
}</pre>
          <div style="font-size: 0.85rem; color: var(--text-secondary);">
            <p style="margin: 0.3rem 0; padding-top: 2.2rem;">⬅️ Start of the rule</p>
            <p style="margin: 0.3rem 0; padding-top: 0.3rem;">⬅️ <strong>"Allow"</strong> = Permission granted</p>
            <p style="margin: 0.3rem 0; padding-top: 0.3rem;">⬅️ <strong>"s3:GetObject"</strong> = Read/download files</p>
            <p style="margin: 0.3rem 0; padding-top: 0.3rem;">⬅️ <strong>"...bucket/public/*"</strong> = The "public" folder and everything inside it</p>
          </div>
        </div>
        
        <div style="background: #dcfce7; padding: 1rem; border-radius: 8px; margin: 1rem 0;">
          <p style="margin: 0;"><strong>✅ In plain English:</strong> "Allow reading any file in the public folder"</p>
        </div>
        
        <hr style="margin: 1.5rem 0; border-color: var(--border);">
        
        <h2>📋 Quick Reference: Key Concepts</h2>
        <table style="width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: 0.9rem;">
          <tr style="background: var(--bg-tertiary);">
            <th style="padding: 0.5rem; text-align: left; border-bottom: 1px solid var(--border);">You'll See</th>
            <th style="padding: 0.5rem; text-align: left; border-bottom: 1px solid var(--border);">It Means</th>
          </tr>
          <tr>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);"><code>Resource</code></td>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);">📁 Which folders/files this rule applies TO</td>
          </tr>
          <tr>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);"><code>NotResource</code></td>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);">📁 Which folders/files this rule does NOT apply to (everything else!)</td>
          </tr>
          <tr>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);"><code>*</code> (asterisk)</td>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);">🃏 Wildcard — matches anything</td>
          </tr>
          <tr>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);"><code>folder/*</code></td>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);">📁 Everything inside that folder</td>
          </tr>
          <tr>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);"><code>Condition</code></td>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);">🔒 Extra conditions (MFA required, encryption, etc.)</td>
          </tr>
          <tr>
            <td style="padding: 0.5rem;"><code>Deny</code> overrides <code>Allow</code></td>
            <td style="padding: 0.5rem;">🚫 If both exist, Deny always wins</td>
          </tr>
        </table>
        
        <hr style="margin: 1.5rem 0; border-color: var(--border);">
        
        <h2>🛠️ What is PolicySummarizer?</h2>
        <p><strong>PolicySummarizer</strong> is a tool that reads complex policies and outputs a <strong>resource regex</strong> — a pattern that shows exactly which resource paths are accessible.</p>
        
        <p>Instead of reading confusing code, you see this:</p>
        <pre style="font-size: 0.8rem; background: var(--code-bg); padding: 1rem; overflow-x: auto;">
PolicySummarizer Output
━━━━━━━━━━━━━━━━━━━━━━━━━━
Accessible Resource Regex:

  my-bucket/public/.*</pre>
        
        <div style="background: #dcfce7; padding: 1rem; border-radius: 8px; margin: 1rem 0;">
          <p style="margin: 0;"><strong>💡 Key insight:</strong> The regex shows ALL resource paths accessible by the policy. Read it carefully — it tells you exactly where access is granted.</p>
        </div>

        <h3>Reading Resource Regexes</h3>
        <table style="width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: 0.9rem;">
          <tr style="background: var(--bg-tertiary);">
            <th style="padding: 0.5rem; text-align: left; border-bottom: 1px solid var(--border);">Regex</th>
            <th style="padding: 0.5rem; text-align: left; border-bottom: 1px solid var(--border);">Meaning</th>
          </tr>
          <tr>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);"><code>bucket/logs/.*</code></td>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);">Only the logs/ folder in bucket</td>
          </tr>
          <tr>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);"><code>bucket/(?!admin/).*</code></td>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);">Everything in bucket EXCEPT admin/</td>
          </tr>
          <tr>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);"><code>bucket/(docs|assets)/.*</code></td>
            <td style="padding: 0.5rem; border-bottom: 1px solid var(--border);">Only docs/ and assets/ in bucket</td>
          </tr>
          <tr>
            <td style="padding: 0.5rem;"><code>.*</code></td>
            <td style="padding: 0.5rem;">⚠️ Everything — the policy is wide open!</td>
          </tr>
        </table>
        
        <hr style="margin: 1.5rem 0; border-color: var(--border);">
        
        <h2>🎯 Practice Question 1: Auditing</h2>
        
        <div class="scenario-box">
          <strong>Question:</strong> A team says this policy gives access to the entire <code>my-bucket</code>. What resource paths does it actually allow?
        </div>
        
        <h3>Step 1: Look at the PolicySummarizer Output</h3>
        <pre style="font-size: 0.8rem; background: var(--code-bg); padding: 1rem; overflow-x: auto;">
PolicySummarizer Output
━━━━━━━━━━━━━━━━━━━━━━━━━━
Accessible Resource Regex:

  my-bucket/(?!admin/|config/).*</pre>
        
        <h3>Step 2: Interpret the Regex</h3>
        <div style="background: var(--bg-tertiary); padding: 1rem; border-radius: 8px; margin: 1rem 0;">
          <p style="margin: 0.3rem 0;">📋 The output shows <code>my-bucket/(?!admin/|config/).*</code></p>
          <p style="margin: 0.3rem 0;">📋 <code>(?!admin/|config/)</code> means "NOT admin/ or config/"</p>
          <p style="margin: 0.3rem 0;">🤔 <strong>Wait...</strong> the team said the entire bucket is accessible...</p>
          <p style="margin: 0.3rem 0;">💡 But PolicySummarizer shows <code>admin/</code> and <code>config/</code> are excluded!</p>
        </div>
        
        <h3>Step 3: Answer</h3>
        <div style="background: #fee2e2; padding: 1rem; border-radius: 8px; margin: 1rem 0;">
          <p style="margin: 0;"><strong>❌ The team is WRONG!</strong> The policy allows access to everything in my-bucket EXCEPT <code>admin/</code> and <code>config/</code>.</p>
          <p style="margin: 0.5rem 0 0 0; font-size: 0.9rem;">Two folders are protected that the team didn't mention.</p>
        </div>
        
        <hr style="margin: 1.5rem 0; border-color: var(--border);">
        
        <h2>🎯 Practice Question 2: Differential</h2>
        
        <div class="scenario-box">
          <strong>Question:</strong> A team updated a policy and says "just added staging access." What actually changed?
        </div>
        
        <h3>Step 1: Look at the Differential Output</h3>
        <pre style="font-size: 0.8rem; background: var(--code-bg); padding: 1rem; overflow-x: auto;">
PolicySummarizer Differential Output
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Before Resource Regex:  app-bucket/src/.*
After Resource Regex:   app-bucket/(src|staging)/.*

Added (in new, not in old):    app-bucket/staging/.*
Removed (in old, not in new):  ∅</pre>
        
        <h3>Step 2: Interpret the Output</h3>
        <div style="background: var(--bg-tertiary); padding: 1rem; border-radius: 8px; margin: 1rem 0;">
          <p style="margin: 0.3rem 0;">📋 <strong>Added:</strong> <code>app-bucket/staging/.*</code> — the staging folder is now accessible</p>
          <p style="margin: 0.3rem 0;">📋 <strong>Removed: ∅</strong> — nothing lost access</p>
          <p style="margin: 0.3rem 0;">💡 The team's claim checks out — they only added staging access.</p>
        </div>
        
        <h3>Step 3: Answer</h3>
        <div style="background: #dcfce7; padding: 1rem; border-radius: 8px; margin: 1rem 0;">
          <p style="margin: 0;"><strong>✅ The team is RIGHT!</strong> Only <code>app-bucket/staging/.*</code> was added. No existing access was changed.</p>
        </div>
        
        <hr style="margin: 1.5rem 0; border-color: var(--border);">
        
        <h2>✅ You're Ready!</h2>
        <p>Remember these simple rules:</p>
        <ul style="margin-left: 1.5rem; margin-bottom: 1rem; color: var(--text-secondary);">
          <li>📋 <strong>Read the resource regex carefully</strong> — it shows exactly which paths are accessible</li>
          <li>🔍 <strong>Look for patterns</strong> — <code>(?!folder/)</code> means that folder is excluded</li>
          <li>📊 <strong>Check Added/Removed</strong> — in differential mode, this shows what changed</li>
          <li>🚫 <strong>Don't trust appearances</strong> — policies can look different but may allow the same access!</li>
        </ul>
        
        <div class="button-group">
          <button class="btn btn-secondary" id="tutorialBackBtn">← Back</button>
          <button class="btn btn-primary" id="tutorialNextBtn">I'm Ready — Continue to Instructions</button>
        </div>
      </div>
    `;

    document.getElementById('tutorialBackBtn').addEventListener('click', () => this.prevStep());

    document.getElementById('tutorialNextBtn').addEventListener('click', () => {
      this.nextStep();
    });
  }

  renderInstructions() {
    const main = document.getElementById('mainContent');
    main.innerHTML = `
      <div class="card">
        <h1>Instructions</h1>
        
        <h2>What You'll Do</h2>
        <p>You will see <strong>2 different scenarios</strong>. For each scenario, you'll answer questions twice:</p>
        <ul style="margin-left: 1.5rem; margin-bottom: 1rem; color: var(--text-secondary);">
          <li><strong>Round 1:</strong> Without PolicySummarizer (just the raw policy)</li>
          <li><strong>Round 2:</strong> With PolicySummarizer (policy + summary table)</li>
        </ul>
        <p>That's <strong>4 tasks total</strong> (2 scenarios × 2 rounds).</p>
        
        <hr style="margin: 1.5rem 0; border-color: var(--border);">
        
        <h2>Side-by-Side: What You'll See</h2>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
          <div style="background: var(--bg-tertiary); padding: 1rem; border-radius: 8px;">
            <p style="font-weight: bold; margin-bottom: 0.5rem;">❌ Without PolicySummarizer</p>
            <p style="font-size: 0.875rem; color: var(--text-secondary);">You only see the raw JSON policy:</p>
            <pre style="font-size: 0.65rem; overflow-x: auto;">{
  "Statement": [{
    "Effect": "Allow",
    "Action": "s3:GetObject",
    "Resource": "arn:aws:s3:::
      my-bucket/public/*"
  }]
}</pre>
          </div>
          <div style="background: var(--bg-tertiary); padding: 1rem; border-radius: 8px;">
            <p style="font-weight: bold; margin-bottom: 0.5rem;">✓ With PolicySummarizer</p>
            <p style="font-size: 0.875rem; color: var(--text-secondary);">You see the JSON + a resource regex:</p>
            <pre style="font-size: 0.65rem; background: var(--code-bg); padding: 0.5rem; overflow-x: auto;">PolicySummarizer Output
━━━━━━━━━━━━━━━━━━━━━━━━
Accessible Resource Regex:

  my-bucket/public/.*</pre>
          </div>
        </div>
        
        <hr style="margin: 1.5rem 0; border-color: var(--border);">
        
        <h2>Tips for Success</h2>
        <ul style="margin-left: 1.5rem; margin-bottom: 1rem; color: var(--text-secondary);">
          <li>⏱️ <strong>A timer is visible</strong> — work at a comfortable pace</li>
          <li>⬅️ <strong>You cannot go back</strong> once you submit an answer</li>
          <li>💡 <strong>Do your best</strong> — there's no penalty for wrong answers</li>
          <li>📝 <strong>Read carefully</strong> — the questions ask about specific details</li>
        </ul>
        
        <div class="scenario-box">
          <p><strong>Ready?</strong> Click the button below to start. The timer begins immediately.</p>
        </div>
        
        <div class="button-group">
          <button class="btn btn-secondary" id="instructionsBackBtn">← Back</button>
          <button class="btn btn-primary" id="startBtn">Start Tasks</button>
        </div>
      </div>
    `;

    document.getElementById('instructionsBackBtn').addEventListener('click', () => this.prevStep());

    document.getElementById('startBtn').addEventListener('click', () => {
      this.responses.startTime = new Date().toISOString();
      this.nextStep();
    });
  }

  renderTask(stepId) {
    // Parse step ID: "task-1-first" or "task-2-second"
    const parts = stepId.split('-');
    const questionIndex = parseInt(parts[1]) - 1; // 0, 1, or 2
    const isSecondCondition = parts[2] === 'second';

    const question = QUESTIONS[questionIndex];
    const counterbalance = COUNTERBALANCE_GROUPS[this.group];

    // Determine condition based on counterbalancing
    let condition;
    if (isSecondCondition) {
      condition = counterbalance.secondCondition[questionIndex];
    } else {
      condition = counterbalance.firstCondition[questionIndex];
    }

    const showPolicySummarizer = condition === 'policySummarizer';
    const conditionLabel = showPolicySummarizer ? 'With PolicySummarizer' : 'Without PolicySummarizer';
    const attemptNum = isSecondCondition ? 2 : 1;

    // Start timer
    this.currentTaskStartTime = Date.now();
    this.startTimer();

    const main = document.getElementById('mainContent');
    main.innerHTML = `
      <div class="card">
        <div class="task-header">
          <div>
            <h1>Task ${questionIndex + 1}.${attemptNum}: ${question.title}</h1>
            <span class="task-badge">${conditionLabel}</span>
          </div>
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <button class="btn-tutorial" id="openTutorialBtn">📚 Tutorial</button>
            <div class="timer" id="timer">
              <svg class="timer-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12,6 12,12 16,14"/>
              </svg>
              <span id="timerDisplay">00:00</span>
            </div>
          </div>
        </div>
        
        <div class="scenario-box">
          <p>${question.scenario.replace(/\n/g, '<br>')}</p>
        </div>
        
        ${this.renderPolicies(question, showPolicySummarizer)}
        
        <form id="taskForm">
          ${this.renderQuestions(question.questions)}
          
          <div class="button-group">
            <button type="button" class="btn btn-secondary" id="taskBackBtn">← Back</button>
            <button type="submit" class="btn btn-primary">Submit & Continue</button>
          </div>
        </form>
      </div>
    `;

    this.setupFormListeners(question.questions);

    document.getElementById('taskForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.submitTask(question, condition, isSecondCondition);
    });

    // Tutorial reference button
    document.getElementById('taskBackBtn').addEventListener('click', () => {
      this.stopTimer();
      this.prevStep();
    });

    document.getElementById('openTutorialBtn').addEventListener('click', () => {
      this.openTutorial();
    });
  }

  renderPolicies(question, showPolicySummarizer) {
    let html = '';

    // Before/After comparison (differential scenario)
    if (question.originalPolicy && question.policy && !question.refactorA) {
      html += `
        <div class="code-label">BEFORE Policy (Legacy)</div>
        <div class="code-block">${this.escapeHtml(question.originalPolicy)}</div>
        
        <div class="code-label">AFTER Policy (Rewritten)</div>
        <div class="code-block">${this.escapeHtml(question.policy)}</div>
      `;
    }
    // Three-way comparison - has originalPolicy, refactorA, modifiedPolicy
    else if (question.originalPolicy && question.refactorA && question.modifiedPolicy) {
      html += `
        <div class="code-label">Original Policy</div>
        <div class="code-block">${this.escapeHtml(question.originalPolicy)}</div>
        
        <div class="code-label">Refactor A (Alice)</div>
        <div class="code-block">${this.escapeHtml(question.refactorA)}</div>
        
        <div class="code-label">Refactor B (Bob)</div>
        <div class="code-block">${this.escapeHtml(question.modifiedPolicy)}</div>
      `;
    }
    // Q3: Compare AI policies - has policyA and policy (policy B)
    else if (question.policyA && question.policy) {
      html += `
        <div class="code-label">Policy A</div>
        <div class="code-block">${this.escapeHtml(question.policyA)}</div>
        
        <div class="code-label">Policy B</div>
        <div class="code-block">${this.escapeHtml(question.policy)}</div>
      `;
    }
    // Q2 or any single policy question
    else if (question.policy) {
      html += `
        <div class="code-label">Policy Under Review</div>
        <div class="code-block">${this.escapeHtml(question.policy)}</div>
      `;
    }

    if (showPolicySummarizer) {
      html += `
        <div class="code-label">PolicySummarizer Analysis</div>
        <div class="policy-summarizer-output">${this.escapeHtml(question.policySummarizerOutput)}</div>
        <div style="background: var(--bg-tertiary); padding: 0.75rem 1rem; border-radius: 8px; margin-top: 0.5rem; font-size: 0.82rem; color: var(--text-secondary); line-height: 1.6;">
          <strong style="color: var(--text-primary);">💡 How to read this:</strong><br>
          • Each <strong>Actions</strong> block = one type of operation (e.g., reading files, writing files)<br>
          • <strong>Simplified Regex</strong> = which folders/files that operation can <em>actually</em> access (<code>.*</code> means <em>everything</em>)<br>
          • <strong>✅</strong> = this access was mathematically verified to be correct<br>
          • <strong>Important:</strong> Deny rules are already factored in — this shows the <em>final net result</em> of what's accessible after all Allow and Deny rules are combined. If something is denied, it won't appear here.
        </div>
      `;
    }

    return html;
  }

  renderQuestions(questions) {
    return questions.map(q => {
      switch (q.type) {
        case 'radio':
          return `
            <div class="form-group" id="group-${q.id}">
              <label>${q.text}</label>
              <div class="options">
                ${q.options.map(opt => `
                  <label class="option" for="${q.id}_${opt.value}">
                    <input type="radio" name="${q.id}" id="${q.id}_${opt.value}" value="${opt.value}" required>
                    <div class="option-content">
                      <span class="option-label">${opt.label}</span>
                    </div>
                  </label>
                `).join('')}
              </div>
            </div>
          `;

        case 'textarea':
          const showIfAttr = q.showIf ? `data-show-if="${q.showIf.question}" data-show-value="${q.showIf.value}"` : '';
          const hiddenClass = q.showIf ? 'style="display:none"' : '';
          const placeholder = q.placeholder || 'Your answer...';
          return `
            <div class="form-group" id="group-${q.id}" ${hiddenClass} ${showIfAttr}>
              <label for="${q.id}">${q.text}</label>
              <textarea id="${q.id}" name="${q.id}" placeholder="${placeholder}"></textarea>
            </div>
          `;

        case 'likert':
          return `
            <div class="form-group" id="group-${q.id}">
              <label>${q.text}</label>
              <div class="likert-scale">
                ${Array.from({ length: q.scale }, (_, i) => i + 1).map(n => `
                  <div class="likert-option">
                    <input type="radio" name="${q.id}" id="${q.id}_${n}" value="${n}" required>
                    <label for="${q.id}_${n}">${n}</label>
                  </div>
                `).join('')}
              </div>
              <div class="likert-labels">
                <span>Not confident</span>
                <span>Very confident</span>
              </div>
            </div>
          `;

        default:
          return '';
      }
    }).join('');
  }

  setupFormListeners(questions) {
    // Handle conditional visibility
    document.querySelectorAll('[data-show-if]').forEach(el => {
      const dependsOn = el.dataset.showIf;
      const showValue = el.dataset.showValue;

      document.querySelectorAll(`input[name="${dependsOn}"]`).forEach(input => {
        input.addEventListener('change', () => {
          el.style.display = input.value === showValue && input.checked ? 'block' : 'none';
        });
      });
    });

    // Handle option selection styling
    document.querySelectorAll('.option').forEach(option => {
      const input = option.querySelector('input');
      input.addEventListener('change', () => {
        option.closest('.options').querySelectorAll('.option').forEach(o => o.classList.remove('selected'));
        option.classList.add('selected');
      });
    });
  }

  startTimer() {
    this.updateTimerDisplay();
    this.timerInterval = setInterval(() => this.updateTimerDisplay(), 1000);
  }

  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  updateTimerDisplay() {
    const elapsed = Math.floor((Date.now() - this.currentTaskStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60).toString().padStart(2, '0');
    const seconds = (elapsed % 60).toString().padStart(2, '0');
    const display = document.getElementById('timerDisplay');
    if (display) {
      display.textContent = `${minutes}:${seconds}`;
    }
  }

  submitTask(question, condition, isSecondAttempt) {
    this.stopTimer();

    const duration = Math.floor((Date.now() - this.currentTaskStartTime) / 1000);

    // Collect responses
    const taskResponse = {
      questionId: question.id,
      questionTitle: question.title,
      condition: condition,
      attempt: isSecondAttempt ? 2 : 1,
      startTime: new Date(this.currentTaskStartTime).toISOString(),
      endTime: new Date().toISOString(),
      durationSeconds: duration,
      answers: {}
    };

    question.questions.forEach(q => {
      if (q.type === 'radio' || q.type === 'likert') {
        const selected = document.querySelector(`input[name="${q.id}"]:checked`);
        taskResponse.answers[q.id] = selected ? selected.value : null;

        // Check correctness if there's a correct answer
        if (q.correctAnswer) {
          taskResponse.answers[`${q.id}_correct`] = selected?.value === q.correctAnswer;
        }
      } else if (q.type === 'textarea') {
        taskResponse.answers[q.id] = document.getElementById(q.id)?.value || '';
      }
    });

    this.responses.tasks.push(taskResponse);
    this.nextStep();
  }

  renderPostStudy() {
    const main = document.getElementById('mainContent');
    main.innerHTML = `
      <div class="card">
        <h1>Almost Done!</h1>
        <p>Please answer a few final questions about your experience.</p>
        
        <form id="postStudyForm">
          <div class="form-group">
            <label>Overall, which format helped you more?</label>
            <div class="options">
              <label class="option" for="pref_json">
                <input type="radio" name="preference" id="pref_json" value="json" required>
                <div class="option-content">
                  <span class="option-label">Without PolicySummarizer</span>
                </div>
              </label>
              <label class="option" for="pref_ps">
                <input type="radio" name="preference" id="pref_ps" value="policySummarizer" required>
                <div class="option-content">
                  <span class="option-label">JSON + PolicySummarizer</span>
                </div>
              </label>
              <label class="option" for="pref_equal">
                <input type="radio" name="preference" id="pref_equal" value="equal" required>
                <div class="option-content">
                  <span class="option-label">About the same</span>
                </div>
              </label>
            </div>
          </div>
          
          <div class="form-group">
            <label>How mentally demanding were the tasks with <strong>JSON only</strong>?</label>
            <div class="likert-scale">
              ${[1, 2, 3, 4, 5, 6, 7].map(n => `
                <div class="likert-option">
                  <input type="radio" name="demand_json" id="demand_json_${n}" value="${n}" required>
                  <label for="demand_json_${n}">${n}</label>
                </div>
              `).join('')}
            </div>
            <div class="likert-labels">
              <span>Very low</span>
              <span>Very high</span>
            </div>
          </div>
          
          <div class="form-group">
            <label>How mentally demanding were the tasks <strong>with PolicySummarizer</strong>?</label>
            <div class="likert-scale">
              ${[1, 2, 3, 4, 5, 6, 7].map(n => `
                <div class="likert-option">
                  <input type="radio" name="demand_ps" id="demand_ps_${n}" value="${n}" required>
                  <label for="demand_ps_${n}">${n}</label>
                </div>
              `).join('')}
            </div>
            <div class="likert-labels">
              <span>Very low</span>
              <span>Very high</span>
            </div>
          </div>
          
          <div class="form-group">
            <label for="feedback">Any additional comments about the tools or study? (optional)</label>
            <textarea id="feedback" name="feedback" placeholder="Your feedback..."></textarea>
          </div>
          
          <div class="button-group">
            <button type="button" class="btn btn-secondary" id="postStudyBackBtn">← Back</button>
            <button type="submit" class="btn btn-primary">Complete Study</button>
          </div>
        </form>
      </div>
    `;

    // Option selection styling
    document.querySelectorAll('.option').forEach(option => {
      const input = option.querySelector('input');
      input.addEventListener('change', () => {
        option.closest('.options').querySelectorAll('.option').forEach(o => o.classList.remove('selected'));
        option.classList.add('selected');
      });
    });

    document.getElementById('postStudyBackBtn').addEventListener('click', () => this.prevStep());

    document.getElementById('postStudyForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.responses.postStudy = {
        preference: document.querySelector('input[name="preference"]:checked').value,
        mentalDemandJson: parseInt(document.querySelector('input[name="demand_json"]:checked').value),
        mentalDemandPolicySummarizer: parseInt(document.querySelector('input[name="demand_ps"]:checked').value),
        feedback: document.getElementById('feedback').value
      };
      this.responses.endTime = new Date().toISOString();
      this.nextStep();
    });
  }

  renderComplete() {
    // Clear saved progress
    localStorage.removeItem('userStudyProgress');

    const main = document.getElementById('mainContent');
    main.innerHTML = `
      <div class="card completion-card">
        <div class="completion-icon" id="completionIcon">⏳</div>
        <h1>Submitting...</h1>
        <p id="statusText">Saving your responses...</p>
      </div>
    `;

    // Prepare final data
    const finalData = {
      participantId: this.participantId,
      group: this.group,
      ...this.responses,
      submittedAt: new Date().toISOString()
    };

    // Submit to JSONBin
    submitToJSONBin(finalData).then(result => {
      const icon = document.getElementById('completionIcon');
      const status = document.getElementById('statusText');

      main.innerHTML = `
        <div class="card completion-card">
          <div class="completion-icon">${result.success ? '✓' : '⚠️'}</div>
          <h1>Thank You!</h1>
          <p>You have successfully completed the user study.</p>
          <p style="color: var(--text-secondary);">
            ${result.success
          ? 'Your responses have been securely recorded.'
          : 'Auto-save failed. Please download your responses below and email them to the researcher.'}
          </p>
          
          <div class="button-group" style="justify-content: center; margin-top: 2rem;">
            <button class="btn btn-secondary" id="downloadBtn">Download My Responses</button>
          </div>
          

        </div>
      `;

      document.getElementById('downloadBtn').addEventListener('click', () => {
        this.downloadResponses();
      });
    });

    // Also log to console for easy access
    console.log('Study Complete. Responses:', JSON.stringify(this.responses, null, 2));
  }

  downloadResponses() {
    const data = {
      participantId: this.participantId,
      group: this.group,
      ...this.responses
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `user_study_responses.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  nextStep() {
    this.currentStep++;
    this.saveProgress();
    this.render();
  }

  prevStep() {
    if (this.currentStep > 0) {
      this.currentStep--;
      this.saveProgress();
      this.render();
    }
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.study = new UserStudy();
});
